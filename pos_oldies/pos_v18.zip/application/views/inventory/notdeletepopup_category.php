<div class="modal-dialog">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body text-center" id="msg">
            <p> <strong>This category belongs to some product. So remove this category from that product. Then you can delete it.</strong></p>
        </div>
        
    </div>
</div>
