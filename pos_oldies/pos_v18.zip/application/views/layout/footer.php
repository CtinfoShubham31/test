<footer class="footer-mini">
<!--    <div>
        <div class="row">
            <div class="col-md-3 col-sm-6">
                <h4> Our Dishes </h4>
                <ul class="list-unstyled">
                    <li><a href="index.html"> Chinese </a></li>
                    <li><a href="about.html"> Chicken Biryani </a></li>
                    <li><a href="services.html"> Burger </a></li>
                    <li><a href="industries.html"> Noodles </a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6">
                <h4> Support/Help </h4>
                <ul class="list-unstyled">
                    <li><a href="index.html"> Contact Us </a></li>
                    <li><a href="about.html"> Privacy Policy </a></li>
                    <li><a href="services.html"> Terms and Conditions </a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6">
                <h4> Company </h4>
                <ul class="list-unstyled">
                    <li> <a href="web-development.html"> About Us </a></li>
                    <li> <a href="digital-marketing.html"> Blog </a></li>
                    <li> <a href="creative-services.html"> Report </a></li>
                </ul>
            </div>
            <div class="col-md-3 col-sm-6">
                <h4> Contact Us </h4>
                <img src="img/logo.png" class="img-responsive"> <br/>
                <ul class="list-unstyled">
                    <li><span><i class="fa fa-phone" aria-hidden="true"></i></span> 123-4567-89547 </li>
                    <li><span><i class="fa fa-envelope" aria-hidden="true"></i></span> domesticmeal@gmail.com </li>
                </ul>
                <div class="social-top">
                    <ul class="list-inline social-ul social-bottom">
                        <li> <a id="fb" href="" target="_blank"><i class="fa fa-facebook fa-fw" aria-hidden="true"></i></a> </li>
                        <li> <a id="twit" href="" target="_blank"><i class="fa fa-twitter fa-fw" aria-hidden="true"></i></a> </li>
                        <li> <a id="google" href="" target="_blank"><i class="fa fa-google fa-fw" aria-hidden="true"></i></a> </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>-->

    <section class="bottom bottom-mini">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p> &copy; 2016 copyrights Domestic Meal | All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </section>
<!---------------------------------------------------------> 

</footer>