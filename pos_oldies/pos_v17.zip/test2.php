<?php

$location = "St. Josed father's institute";
$location = mysql_real_escape_string($location);
echo $location;
$str = "Is your name O'reilly?";
// Outputs: Is your name O\'reilly?
echo addslashes($str);

die('zzz');

echo date_default_timezone_get();

echo $date = date('Y-m-d H:i:s');

echo '<br/>';
//date_default_timezone_set('Asia/Calcutta');
date_default_timezone_set('Africa/Nairobi');
echo $date = date('Y-m-d H:i:s');