<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_user extends MY_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('common'));
        $this->output->nocache();
        if(!isAdminLogin()) { 
            redirect($this->config->base_url().'ks_admin/admin_home/logout');
        }
       
    }
    
    /*-----Load all user------*/
    public function user_lists() { //die('EEE');
        $this->layout->css('admin_design/css/dataTables.min.css');
        $this->layout->js('admin_design/js/jquery.dataTables.min.js');
        $this->layout->view('admin_user/user_lists');
    }
    
    public function ajax_userlists(){
        $this->load->model('admin_user_model');
        $user_records =  $this->admin_user_model->getUsers();
        if(!empty($user_records)){
            $total_count =  count($user_records);
        }else{
            $total_count =  0;
        }
        $this->admin_user_model->getUserListsResponse($total_count);
    }
    
    public function remove_superuser(){
        $this->load->model('admin_user_model');
        if($this->input->post('user_id')){
            $user_id = $this->input->post('user_id');
            $company_id = $this->session->userdata('ks_company_id');
            
            $update_data = array('is_super_user'=>0);
            $user_records =  $this->admin_user_model->updateUserData($user_id,$company_id,$update_data);
            if($user_records){
                echo 'true';
            }else{
                echo 'false';
            }
        }
    }
    
    public function add_superuser(){
        $this->load->model('admin_user_model');
        if($this->input->post('user_id')){
            $user_id = $this->input->post('user_id');
            $company_id = $this->session->userdata('ks_company_id');
            
            $update_data = array('is_super_user'=>1);
            $user_records =  $this->admin_user_model->updateUserData($user_id,$company_id,$update_data);
            if($user_records){
                echo 'true';
            }else{
                echo 'false';
            }
        }
    }
    
    
}