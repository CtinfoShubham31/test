<div class="modal-dialog modal-md">
        <!-- Modal content-->
        <div class="modal-content mini-modal">
            <div class="modal-header">
                <h4 class="modal-title">Post Status</h4>
                <button type="button" class="close" data-dismiss="modal">×</button>
            </div>
            <div class="modal-body">
                <h5><?php echo $udetails->first_name.' '.$udetails->last_name.' is editing the posts. Please wait for a while.'?></h5>      
            </div>
        </div>
    
    </div>