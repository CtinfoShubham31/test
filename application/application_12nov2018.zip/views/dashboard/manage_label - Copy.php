<section id="post" class="post-sec">
<div class="container">
    <div class="row">
    <div class="col-md-12">
        <div class="add-post">
             <h3 class="h3-heading">Manage Labels</h3>
             <div class="row">
            <?php echo manageLables();?>
             </div>
             </div>
    </div>
</div>
</div>
    </section>
           