<!-- Modal -->
  <div class="modal fade" id="post_restrict" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">

          <button type="button" class="close close-space" data-dismiss="modal">&times;</button>
        <div class="modal-body">
            <div class="alert alert-danger">
                You are not authorized to view this posts.
            </div>
        </div>

      </div>
      
    </div>
  </div>

<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#post_restrict">Open Modal</button>

<script>
    
</script>